import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-group-manager',
  templateUrl: './group-manager.component.html',
  styleUrls: ['./group-manager.component.css']
})
export class GroupManagerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
