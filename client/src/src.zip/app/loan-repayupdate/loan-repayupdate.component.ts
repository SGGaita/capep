import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loan-repayupdate',
  templateUrl: './loan-repayupdate.component.html',
  styleUrls: ['./loan-repayupdate.component.css']
})
export class LoanRepayupdateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
