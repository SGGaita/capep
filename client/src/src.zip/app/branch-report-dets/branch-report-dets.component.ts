import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-branch-report-dets',
  templateUrl: './branch-report-dets.component.html',
  styleUrls: ['./branch-report-dets.component.css']
})
export class BranchReportDetsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
