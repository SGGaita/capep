import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-group-reports',
  templateUrl: './group-reports.component.html',
  styleUrls: ['./group-reports.component.css']
})
export class GroupReportsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
