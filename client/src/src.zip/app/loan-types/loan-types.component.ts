import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loan-types',
  templateUrl: './loan-types.component.html',
  styleUrls: ['./loan-types.component.css']
})
export class LoanTypesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
