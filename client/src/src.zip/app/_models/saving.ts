export class Saving {
  savings_id: number;
  member_id_fk: number;
  savings_amount: number;
  total_payment: number;
  savings_bf: number;
  comments: string;
  savings_date: Date;
  _savings_total: number;
  default_amount: number
}
