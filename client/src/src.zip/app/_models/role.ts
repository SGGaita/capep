export enum Role {
    User = 'USER',
    Admin = 'ADMIN',
    SAdmin = 'SADMIN'
  }