import { Officials } from './officials';

describe('Officials', () => {
  it('should create an instance', () => {
    expect(new Officials()).toBeTruthy();
  });
});
