export class LoanConditions {
    group_months: number;
    group_membership: number;
    minimum_savings: number;
    createdAt: Date;
    updated: Date;
}
