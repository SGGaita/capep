export class LoanRates {
  map(arg0: (a: any) => any): any {
    throw new Error("Method not implemented.");
  }
    normal_rate: number;
    advance_rate: number;
    default_rate: number;
    createdAt: Date;
    updatedAt: Date;
    long_term: number;
    adv_term: number;
    insurance_rate: number;
}
