export class Dividend {
    dividend_id: number;
    member_id_fk: number;
    dividend_amount: number;
    dividend_rate: number;
    purpose_1: string;
    purpose_2: string;
    purpose_3: string;
    createdAt: Date;
    updatedAt: Date;

}
