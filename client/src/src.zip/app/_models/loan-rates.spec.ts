import { LoanRates } from './loan-rates';

describe('LoanRates', () => {
  it('should create an instance', () => {
    expect(new LoanRates()).toBeTruthy();
  });
});
