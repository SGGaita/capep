import { LoanRepay } from './loan-repay';

describe('LoanRepay', () => {
  it('should create an instance', () => {
    expect(new LoanRepay()).toBeTruthy();
  });
});
