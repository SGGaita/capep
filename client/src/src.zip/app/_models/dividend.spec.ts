import { Dividend } from './dividend';

describe('Dividend', () => {
  it('should create an instance', () => {
    expect(new Dividend()).toBeTruthy();
  });
});
