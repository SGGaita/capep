import { LoanRepayPeriod } from './loan-repay-period';

describe('LoanRepayPeriod', () => {
  it('should create an instance', () => {
    expect(new LoanRepayPeriod()).toBeTruthy();
  });
});
