export class User {
    user_id: number;
    name: string;
    userName:string;
    email: string;
    password: string;
    phone_number: string;
    gender: string;
    roles: string;
    created_at: Date;
    updated_at: Date;    
}
