export class DivPurpose {
    purpose_id: number;
    purpose_name: string;
}
