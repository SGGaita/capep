import { Loans } from './loans';

describe('Loans', () => {
  it('should create an instance', () => {
    expect(new Loans()).toBeTruthy();
  });
});
