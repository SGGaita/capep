export class Branch {
  map(arg0: (a: any) => any): string {
    throw new Error("Method not implemented.");
  }
    branch_id: number;
    branch_name: string;
    branch_code: string;
    branch_description: string;
    branch_createdat: Date;
    
}
