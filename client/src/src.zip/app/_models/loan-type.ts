export class LoanType {
    loan_type_id: number;
    type_name: string;
}
