import { Branch } from "./Branch.1";

describe('Branch', () => {
  it('should create an instance', () => {
    expect(new Branch()).toBeTruthy();
  });
});
