export class Officials {
}
