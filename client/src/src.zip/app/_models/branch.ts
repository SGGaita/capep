export class Branch {
    branch_id: number;
    branch_name: string;
    branch_code: string;
    branch_description: string;
    branch_createdat: Date;
    updated_at: Date;
}
