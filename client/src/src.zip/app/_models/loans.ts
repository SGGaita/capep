export class Loans {
}
