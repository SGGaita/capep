export class Guarantor {
    guarantor_id:number
    loan_id_fk: number;
    member_id_fk: number;
}
