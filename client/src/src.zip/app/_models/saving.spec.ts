import { Saving } from './saving'

describe('Saving', () => {
  it('should create an instance', () => {
    expect(new Saving()).toBeTruthy();
  });
});
