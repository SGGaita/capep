import { DivPurpose } from './div-purpose';

describe('DivPurpose', () => {
  it('should create an instance', () => {
    expect(new DivPurpose()).toBeTruthy();
  });
});
