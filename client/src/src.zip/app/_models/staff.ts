export class Staff {
  map(arg0: (a: any) => any): any {
    throw new Error("Method not implemented.");
  }
    staff_id: number;
    staff_name: string;
    staff_id_number: string;
    staff_email: string;
    staff_phone_number: string;
    staff_gender: string;
    staff_image: string;
    staff_id_image: string;
    createdAt: Date;
    updatedAt: Date;
}
