export class Member {
  map(arg0: (a: any) => any): string {
    throw new Error("Method not implemented.");
  }
    member_id: number;
    group_id_fk: number;
    member_name: string;
    member_id_no: string;
    membership_no: string;
    occupation: string;
    phone_number: string;
    postal_address: string;
    postal_code: string;
    location: string;
    town: string;
    passport_image: string;
    id_image: string;
    signature_image: string;
    next_kin_name: string;
    next_kin_relation: string;
    next_id_number: string;
    next_phone_number: string;
    next_location: string;
    next_town: string;
}
