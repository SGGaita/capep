export class LoanRepayPeriod {
    period_id: number;
    min_range: number;
    max_range: number;
    repay_period: number;
    createdAt: Date;
    updatedAt: Date;
}
