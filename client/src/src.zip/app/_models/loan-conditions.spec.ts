import { LoanConditions } from './loan-conditions';

describe('LoanConditions', () => {
  it('should create an instance', () => {
    expect(new LoanConditions()).toBeTruthy();
  });
});
