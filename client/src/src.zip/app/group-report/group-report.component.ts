import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-group-report',
  templateUrl: './group-report.component.html',
  styleUrls: ['./group-report.component.css']
})
export class GroupReportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
