import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sys-manager',
  templateUrl: './sys-manager.component.html',
  styleUrls: ['./sys-manager.component.css']
})
export class SysManagerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
