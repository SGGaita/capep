import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-membership-manager',
  templateUrl: './membership-manager.component.html',
  styleUrls: ['./membership-manager.component.css']
})
export class MembershipManagerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
