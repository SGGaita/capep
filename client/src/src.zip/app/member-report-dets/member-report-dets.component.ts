import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-member-report-dets',
  templateUrl: './member-report-dets.component.html',
  styleUrls: ['./member-report-dets.component.css']
})
export class MemberReportDetsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
