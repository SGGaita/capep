import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loanrepay',
  templateUrl: './loanrepay.component.html',
  styleUrls: ['./loanrepay.component.css']
})
export class LoanrepayComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
