import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loan-repay-period',
  templateUrl: './loan-repay-period.component.html',
  styleUrls: ['./loan-repay-period.component.css']
})
export class LoanRepayPeriodComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
