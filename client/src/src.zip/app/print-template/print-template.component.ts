import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-print-template',
  templateUrl: './print-template.component.html',
  styleUrls: ['./print-template.component.css']
})
export class PrintTemplateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
