import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-group-report-dets',
  templateUrl: './group-report-dets.component.html',
  styleUrls: ['./group-report-dets.component.css']
})
export class GroupReportDetsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
