import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dividend',
  templateUrl: './dividend.component.html',
  styleUrls: ['./dividend.component.css']
})
export class DividendComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
