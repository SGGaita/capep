import { FilterMemberByCodePipe } from './filter-member-by-code.pipe';

describe('FilterMemberByCodePipe', () => {
  it('create an instance', () => {
    const pipe = new FilterMemberByCodePipe();
    expect(pipe).toBeTruthy();
  });
});
