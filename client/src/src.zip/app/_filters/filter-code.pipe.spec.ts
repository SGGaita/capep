import { FilterCodePipe } from './filter-code.pipe';

describe('FilterCodePipe', () => {
  it('create an instance', () => {
    const pipe = new FilterCodePipe();
    expect(pipe).toBeTruthy();
  });
});
