import { FilterGroupByNamePipe } from './filter-group-by-name.pipe';

describe('FilterGroupByNamePipe', () => {
  it('create an instance', () => {
    const pipe = new FilterGroupByNamePipe();
    expect(pipe).toBeTruthy();
  });
});
