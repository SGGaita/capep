import { FilterGroupByCodePipe } from './filter-group--by-code.pipe';

describe('FilterGroupByCodePipe', () => {
  it('create an instance', () => {
    const pipe = new FilterGroupByCodePipe();
    expect(pipe).toBeTruthy();
  });
});
