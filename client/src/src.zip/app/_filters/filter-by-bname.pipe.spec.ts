import { FilterByBnamePipe } from './filter-by-bname.pipe';

describe('FilterByBnamePipe', () => {
  it('create an instance', () => {
    const pipe = new FilterByBnamePipe();
    expect(pipe).toBeTruthy();
  });
});
