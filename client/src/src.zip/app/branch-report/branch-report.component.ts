import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-branch-report',
  templateUrl: './branch-report.component.html',
  styleUrls: ['./branch-report.component.css']
})
export class BranchReportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
